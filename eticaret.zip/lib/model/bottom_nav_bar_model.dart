class BottomNavBarModel {
  String image;
  String title;
  BottomNavBarModel({
    required this.image,
    required this.title,
  });
}
