import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:grock/grock.dart';
import 'package:youtube_ecommerce_app/constant/constant.dart';
import 'package:youtube_ecommerce_app/view/splash.dart';

void main() => runApp(ProviderScope(child: MyApp()));

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Youtube ECommerce App',
      debugShowCheckedModeBanner: false,
      navigatorKey: Grock.navigationKey,
      theme: ThemeData(
        scaffoldBackgroundColor: Constant.white,
      ),
      home: Scaffold(
        appBar: AppBar(
          title: Text("My App"),
        ),
        body: Splash(),
      ),
    );
  }
}

// SnackBar göstermek için bu fonksiyonu kullan
void showMySnackBar(BuildContext context) {
  ScaffoldMessenger.of(context).showSnackBar(
    SnackBar(
      content: Text("This is a snackbar."),
      duration: Duration(seconds: 2),
    ),
  );
}
