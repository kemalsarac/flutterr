import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: GameScreen(),
    );
  }
}

class GameScreen extends StatefulWidget {
  @override
  _GameScreenState createState() => _GameScreenState();
}

class _GameScreenState extends State<GameScreen> {
  List<String> kelimeListesi = [
    'Pencere',
    'Kalem',
    'Bisiklet',
    'Kuş',
    'Deniz',
  ];

  List<List<String>> yasakliKelimelerListesi = [
    ['bakmak', 'gökyüzü', 'cam'],
    ['kağıt', 'ders', 'uçlu'],
    ['tekerlek', 'binmek', 'pedal'],
    ['kanat', 'hayvan', 'uçmak'],
    ['balık', 'plaj', 'kum'],
  ];

  int mevcutKelimeIndex = 0;
  int puan = 0;

  void sonrakiKelimeyiGoster() {
    setState(() {
      if (mevcutKelimeIndex < kelimeListesi.length - 1) {
        mevcutKelimeIndex++;
      } else {
        // Eğer son kelimeye ulaşıldıysa başa dön
        mevcutKelimeIndex = 0;
      }
    });
  }

  void dogruButonunaBasildi() {
    setState(() {
      puan += 1;
      sonrakiKelimeyiGoster();
    });
  }

  void pasButonunaBasildi() {
    setState(() {
      puan += 0;
      sonrakiKelimeyiGoster();
    });
  }

  void tabuButonunaBasildi() {
    setState(() {
      puan -= 1;
      sonrakiKelimeyiGoster();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFF0D47A1), // Arka plan rengi: Koyu Mavi Tonu
      appBar: AppBar(
        leading: Padding(
          padding: const EdgeInsets.all(2.0),
          child: Text('Puan: $puan', style: TextStyle(fontSize: 20)),
        ),
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: <Widget>[
          Expanded(
            child: Center(
              child: Container(
                decoration: BoxDecoration(
                  color: Color(0xFF000000), // Dikdörtgenin içini siyah yapar
                  border: Border.all(
                    color: Color(0xFF000000),
                    width: 8.0,
                  ),
                  borderRadius: BorderRadius.circular(10.0),
                ),
                padding: EdgeInsets.all(32.0),
                child: Text(
                  kelimeListesi[mevcutKelimeIndex],
                  style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                    color: Color(0xFFFFFFFF), // Yazı rengini beyaz yapar
                  ),
                ),
              ),
            ),
          ),
          SizedBox(height: 20),
          Text(
            'Yasaklı Kelimeler:',
            style: TextStyle(fontSize: 18),
          ),
          Expanded(
            child: ListView.builder(
              itemCount: yasakliKelimelerListesi[mevcutKelimeIndex].length,
              itemBuilder: (context, index) {
                return Container(
                  margin: EdgeInsets.all(8.0),
                  padding: EdgeInsets.all(12.0),
                  decoration: BoxDecoration(
                    color: Color(0xFF000000), // Dikdörtgenin içini siyah yapar
                    border: Border.all(
                      color: Colors.black,
                      width: 2.0,
                    ),
                    borderRadius: BorderRadius.circular(10.0),
                  ),
                  child: Text(
                    yasakliKelimelerListesi[mevcutKelimeIndex][index],
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      color: Color(0xFFFFFFFF), // Yazı rengini beyaz yapar
                    ),
                  ),
                );
              },
            ),
          ),
          SizedBox(height: 20),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: <Widget>[
              ElevatedButton(
                onPressed: tabuButonunaBasildi,
                style: ElevatedButton.styleFrom(
                  shape: CircleBorder(),
                  primary:
                      Color(0xFFFF5722), // "Tabu" buton rengi: Turuncu Tonu
                ),
                child: Container(
                  width: 50,
                  height: 50,
                  child: Center(
                    child: Text(
                      'Tabu',
                      style: TextStyle(color: Colors.white),
                    ),
                  ),
                ),
              ),
              ElevatedButton(
                onPressed: pasButonunaBasildi,
                style: ElevatedButton.styleFrom(
                  shape: CircleBorder(),
                  primary: Color(0xFFD50000), // "Pas" buton rengi: Kırmızı Tonu
                ),
                child: Container(
                  width: 50,
                  height: 50,
                  child: Center(
                    child: Text(
                      'Pas',
                      style: TextStyle(color: Colors.white),
                    ),
                  ),
                ),
              ),
              ElevatedButton(
                onPressed: dogruButonunaBasildi,
                style: ElevatedButton.styleFrom(
                  shape: CircleBorder(),
                  primary: Color(0xFF4CAF50), // "Doğru" buton rengi: Yeşil Tonu
                ),
                child: Container(
                  width: 50,
                  height: 50,
                  child: Center(
                    child: Text(
                      'Doğru',
                      style: TextStyle(color: Colors.white),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
