package com.example.kopek_takip

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
